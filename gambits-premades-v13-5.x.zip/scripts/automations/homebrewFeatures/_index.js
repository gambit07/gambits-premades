import { wound } from "./wound.js";

export const homebrewFeaturesMacros = {
  wound
};