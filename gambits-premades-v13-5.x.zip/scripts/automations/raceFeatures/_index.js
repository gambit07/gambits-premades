import { rabbitHop } from "./rabbitHop.js";

export const raceFeaturesMacros = {
    rabbitHop
};