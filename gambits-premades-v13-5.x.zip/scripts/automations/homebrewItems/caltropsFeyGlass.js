export async function caltropsFeyGlass({tokenUuid, regionUuid, regionScenario, originX, originY, regionStatus}) {
    //It's dead but I still want the homebrew items section here so leaving it as a placeholder
}