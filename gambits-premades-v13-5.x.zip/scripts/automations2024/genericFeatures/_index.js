import { sentinel2024 } from "./sentinel2024.js";
import { mageSlayer2024 } from "./mageSlayer2024.js";
import { shieldMaster2024 } from "./shieldMaster2024.js";

export const genericFeaturesMacros2024 = {
  sentinel2024,
  mageSlayer2024,
  shieldMaster2024
};