import { elementalAffinity2024 } from "./sorcerer/draconicSorcery/elementalAffinity2024.js";
import { indomitable2024 } from "./fighter/indomitable2024.js";
import { recklessAttack2024 } from "./barbarian/recklessAttack2024.js";

export const classFeaturesMacros2024 = {
  elementalAffinity2024,
  indomitable2024,
  recklessAttack2024
};